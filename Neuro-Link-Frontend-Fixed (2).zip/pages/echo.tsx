
import Echo from '@/components/agents/Echo';
export default function EchoPage() { return <Echo />; }
