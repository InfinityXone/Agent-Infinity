
import FinSynapse from '@/components/agents/FinSynapse';
export default function NexusPage() { return <FinSynapse />; }
