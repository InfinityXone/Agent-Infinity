
import Codex from '@/components/agents/Codex';
export default function CodexPage() { return <Codex />; }
